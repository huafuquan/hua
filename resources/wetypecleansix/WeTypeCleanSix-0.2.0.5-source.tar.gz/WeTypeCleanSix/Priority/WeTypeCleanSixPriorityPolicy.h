#ifndef WETYPECLEANSIX_PRIORITY_POLICY_H
#define WETYPECLEANSIX_PRIORITY_POLICY_H
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#define WTS_PERIOD_SECONDS 1800ull
#define WTS_LEEWAY_SECONDS 60ull
#define WTS_WAKE_NS 5000000000ull
typedef struct { uint64_t last; bool sent; } WTSWakeGate;
static inline bool WTSAdmitWake(WTSWakeGate *gate, uint64_t now) {
    if (gate->sent && now - gate->last < WTS_WAKE_NS) return false;
    gate->sent = true;
    gate->last = now;
    return true;
}
static inline bool WTSVisibilityAppeared(bool *visible) {
    if (*visible) return false;
    *visible = true;
    return true;
}
#define WTS_NICE (-18)
#define WTS_JETSAM 100
static inline bool WTSIsTarget(const char *bundleID) {
    return bundleID && strcmp(bundleID, "com.tencent.wetype.keyboard") == 0;
}
static inline bool WTSVerified(int result, int setError, int actual, int readError, int wanted) {
    return result == 0 && setError == 0 && readError == 0 && actual == wanted;
}
#endif
