#import <Foundation/Foundation.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <limits.h>
#include "WeTypeCleanSixPriorityPolicy.h"
#include <notify.h>
#include <time.h>
// Public XNU/libproc ABI; these private declarations are absent from the iOS SDK.
extern int proc_listpids(uint32_t, uint32_t, void *, int);
extern int proc_pidpath(int, void *, uint32_t);
extern int memorystatus_control(uint32_t, int32_t, uint32_t, void *, size_t);
typedef struct { int32_t priority; uint64_t user_data; } WTSPriorityProperties;
typedef struct { pid_t pid; int32_t priority; uint64_t user_data; int32_t limit; uint32_t state; } WTSPriorityEntry;
_Static_assert(sizeof(WTSPriorityProperties) == 16, "XNU priority properties ABI");
_Static_assert(sizeof(WTSPriorityEntry) == 24, "XNU priority entry ABI");

static NSString *WTSPath(pid_t pid) {
    char path[4096] = {0};
    if (pid <= 1 || proc_pidpath(pid, path, sizeof(path)) <= 0) return nil;
    path[sizeof(path)-1] = 0;
    return [NSString stringWithUTF8String:path];
}

static BOOL WTSTarget(pid_t pid, NSString *expected) {
    NSString *path = WTSPath(pid);
    if (!path || (expected && ![path isEqualToString:expected])) return NO;
    NSString *bundle = [path stringByDeletingLastPathComponent];
    if (![bundle.pathExtension isEqualToString:@"appex"]) return NO;
    // Only installed app extensions, never a user supplied configuration or PID.
    if (![bundle hasPrefix:@"/private/var/containers/Bundle/Application/"] &&
        ![bundle hasPrefix:@"/var/containers/Bundle/Application/"]) return NO;
    // /var is the system alias of /private/var. Reject other aliases, traversal
    // and symlinks in the installed-container path (including parent components).
    NSString *canonicalExpected = [path hasPrefix:@"/var/"] ? [@"/private" stringByAppendingString:path] : path;
    char resolved[PATH_MAX];
    if (!realpath(path.fileSystemRepresentation, resolved) ||
        strcmp(resolved, canonicalExpected.fileSystemRepresentation)) return NO;
    NSString *infoPath = [bundle stringByAppendingPathComponent:@"Info.plist"];
    NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:infoPath];
    NSString *bid = info[@"CFBundleIdentifier"];
    NSString *exe = info[@"CFBundleExecutable"];
    // Filesystem owners, NOT process UIDs: root, observed install-managed 33,
    // and mobile. Apply the same bounded allowlist to all three resources.
    for (NSString *file in @[bundle, infoPath, path]) {
        struct stat st;
        errno = 0;
        int rc = lstat(file.fileSystemRepresentation, &st);
        BOOL typeOK = !rc && ([file isEqualToString:bundle] ? S_ISDIR(st.st_mode) : S_ISREG(st.st_mode));
        if (rc || !typeOK || (st.st_uid != 0 && st.st_uid != 33 && st.st_uid != 501) || (st.st_mode & 0022)) return NO;
    }
    return [bid isKindOfClass:NSString.class] && WTSIsTarget(bid.UTF8String) &&
        [exe isKindOfClass:NSString.class] && [exe isEqualToString:path.lastPathComponent];
}

static int WTSJetsam(pid_t pid, int *error) {
    errno = 0;
    WTSPriorityEntry entry = {0};
    int got = memorystatus_control(1, pid, 0, &entry, sizeof(entry));
    int saved = errno;
    if (got != sizeof(entry) || entry.pid != pid) {
        *error = saved ?: ESRCH;
        return INT_MIN;
    }
    *error = 0;
    return entry.priority;
}

// Return verification status without retaining diagnostic state or retrying.
static BOOL WTSApply(pid_t pid, NSString *path) {
    if (!WTSTarget(pid, path)) return NO;
    errno = 0;
    int before = getpriority(PRIO_PROCESS, (id_t)pid);
    int readError = errno;
    BOOL niceOK = !readError && before == WTS_NICE;
    if (!readError && !niceOK) {
        if (!WTSTarget(pid, path)) return NO;
        errno = 0;
        int rc = setpriority(PRIO_PROCESS, (id_t)pid, WTS_NICE);
        int setError = errno;
        errno = 0;
        int actual = getpriority(PRIO_PROCESS, (id_t)pid);
        int verifyError = errno;
        niceOK = WTSVerified(rc, setError, actual, verifyError, WTS_NICE);
    }
    // Independent of Nice failure; read the current value before any write.
    int jetsamError = 0;
    int jetsam = WTSJetsam(pid, &jetsamError);
    if (!jetsamError && jetsam == WTS_JETSAM) return niceOK;
    if (!WTSTarget(pid, path)) return NO;
    WTSPriorityProperties props = { .priority = WTS_JETSAM, .user_data = 0 };
    errno = 0;
    // MEMORYSTATUS_SET_PRIORITY_ASSERTION: exact 100, flags=1; no fallback.
    int rc = memorystatus_control(2, pid, 1, &props, sizeof(props));
    int setError = errno;
    int actual = WTSJetsam(pid, &jetsamError);
    BOOL jetsamOK = WTSVerified(rc, setError, actual, jetsamError, WTS_JETSAM);
    return niceOK && jetsamOK;
}

static void WTSScan(void) {
    int bytes = proc_listpids(1, 0, NULL, 0); // PROC_ALL_PIDS
    if (bytes <= 0 || bytes > 4*1024*1024) return;
    size_t capacity = (size_t)bytes + 4096;
    pid_t *pids = calloc(1, capacity);
    if (!pids) return;
    int got = proc_listpids(1, 0, pids, (int)capacity);
    if (got < 0 || (size_t)got > capacity) { free(pids); return; }
    for (size_t i=0; i<(size_t)got/sizeof(pid_t); i++) {
        NSString *path = WTSPath(pids[i]);
        // Path/executable is a prefilter only; identity and ownership are verified above.
        if (path && WTSTarget(pids[i], path)) WTSApply(pids[i], path);
    }
    free(pids);
}

int main(int argc, char **argv) {
    (void)argv;
    if (argc != 1) return 64;
    if (geteuid() != 0) return 77;
    @autoreleasepool {
        dispatch_queue_t queue = dispatch_queue_create("com.hua.wetypecleansix.priority", DISPATCH_QUEUE_SERIAL);
        // One startup scan, separate from the delayed low-frequency timer.
        WTSScan();
        dispatch_source_t timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
        if (!timer) return 71;
        dispatch_source_set_timer(timer, dispatch_time(DISPATCH_TIME_NOW, WTS_PERIOD_SECONDS*NSEC_PER_SEC),
            WTS_PERIOD_SECONDS*NSEC_PER_SEC, WTS_LEEWAY_SECONDS*NSEC_PER_SEC);
        dispatch_source_set_event_handler(timer, ^{ @autoreleasepool { WTSScan(); } });
        dispatch_resume(timer);
        int token = 0;
        __block WTSWakeGate gate = {0};
        // Failure leaves only startup and periodic checks; never retry/poll.
        (void)notify_register_dispatch("com.hua.wetypecleansix.priority.keyboard-open", &token, queue, ^(int t) {
            (void)t;
            uint64_t now = clock_gettime_nsec_np(CLOCK_MONOTONIC);
            if (!WTSAdmitWake(&gate, now)) return;
            @autoreleasepool { WTSScan(); }
        });
        dispatch_main();
    }
}
