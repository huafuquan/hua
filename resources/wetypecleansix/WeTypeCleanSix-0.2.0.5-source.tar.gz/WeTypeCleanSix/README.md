# WeTypeCleanSix 0.2.0.5 candidate

包：com.hua.wetypecleansix；Author/Maintainer：hua；RootHide，thin arm64e，iOS 15+。准确基线为成功的0.2.0.4源码归档；用户已确认该版本真实Nice=-18、Jetsam=100成功。0.2.0.5本身仍待设备验收。

原六按钮、空选区全文复制/剪切、平滑光标、键帽/候选/外侧及工具栏布局与所有非优先级hook保持源码字节不变。不新增滑动功能、设置面板或通用进程权限。

## 刷新方案

- daemon每次启动扫描一次。
- 仅精确com.tencent.wetype.keyboard中的UIInputViewController从不可见进入可见（viewDidAppear原实现后）发送一次通知；同一controller重复didAppear不重复发送。viewDidDisappear先调用原实现，再清除可见状态；下一次显示才成为新打开事件。状态随controller释放。
- 发送端进程级、接收端队列级均使用CLOCK_MONOTONIC，以5秒前沿节流：窗口内重复打开通知直接丢弃合并，不安排尾沿补发。故不承诺每一次快速重开都单独扫描，也不存在隐藏的延时任务。
- 唯一周期GCD timer为1800秒，leeway60秒；第一次周期在启动扫描约30分钟后，不额外立即触发一次。系统可以延后/合并调度，不是硬实时或唤醒/阻止休眠保证。
- 无输入、layout、候选触发，无优先级高频重试。通知注册/投递失败不重试；仍保留启动/周期扫描。
- 每次先读实际Nice/Jetsam，正确就不写；Nice读失败不盲写Nice，但Jetsam独立尝试。每次写前重验目标路径，写后回读验证，errno独立保存；无Jetsam降级或managed-state修改。失败不现场重试，留待后续正常触发。

这是按需求实施的低频折中，不是实测最优耗电结果。不会保证输入法永不退出；系统回收、退出/崩溃及进程重建仍可能发生。launchd KeepAlive仅管理本包daemon，不负责强制启动/复活输入法。

## 安全与清理

三处目标资源（appex、Info.plist、执行文件）仅允许文件系统owner0/33/501；保留类型、禁止group/world写、拒绝symlink及父路径别名、精确bundle/executable、已安装容器路径边界、每次变更前PID路径重验。文件owner不等于进程UID。保留原有限制；不宣称原子消除文件系统/PID竞态或完整代码签名鉴别。

已从生产删除syslog/文件/stdout日志、O_NOFOLLOW日志辅助/截断、diagnose模式、日志描述符/开关/计数与专用采集器。原0.2.0.4仅在同一文件内截断，无已知轮转文件，因此不猜测删除*.1或通配符。安装脚本先停止旧daemon，再对唯一已知生成路径`/var/log/WeTypeCleanSixPriority.log`执行非递归`rm -f`；卸载/升级prerm也清理此同一路径。末级symlink只删链接不跟随；目录不会递归删除。适用RootHide包脚本路径映射环境。清理发生在用户安装/卸载时，本次没有远程删除设备日志。永久日志不再生成；必要的安装错误消息仍可见。历史源码/交付归档未动。

## 用户Mac构建（不安装）

```sh
export THEOS="$HOME/theos"
export PATH="/opt/homebrew/bin:/usr/local/bin:$THEOS/bin:$PATH"
sh tests/run-mac-tests.sh
gmake clean THEOS_PACKAGE_SCHEME=roothide
gmake -j1 package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=roothide ARCHS=arm64e
python3 tests/normalize-deb-owner.py packages/com.hua.wetypecleansix_0.2.0.5_iphoneos-arm64e.deb
```

归一化只修改deb归档属主为数字0:0，保留载荷与权限。源码MANIFEST.sha256在实际编译输入/导出目录核验。Mac模拟测试直接包含生产daemon源码，另测生产共享五秒/生命周期门控；不等于iOS通知投递或真实30分钟计时测试。无安装、respring、稳定版发布或云端替代构建。
