#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <substrate.h>
#import <mach-o/dyld.h>

static BOOL WeTypeCleanCaretInstalled;
static id (*WeTypeCleanOriginalCaret)(id, SEL);
static id WeTypeCleanSmoothCaret(id self, SEL cmd) {
    return [self valueForKey:@"m_caretView"];
}
static void WeTypeCleanInstallCaret(void) {
    if (WeTypeCleanCaretInstalled) return;
    NSInteger major = NSProcessInfo.processInfo.operatingSystemVersion.majorVersion;
    if (major != 15 && major != 16) return;
    Class cls = objc_getClass("UITextSelectionView");
    SEL sel = sel_registerName("dynamicCaret");
    if (!cls || !class_getInstanceVariable(cls, "m_caretView") ||
        !class_getInstanceMethod(cls, sel)) return;
    MSHookMessageEx(cls, sel, (IMP)WeTypeCleanSmoothCaret, (IMP *)&WeTypeCleanOriginalCaret);
    WeTypeCleanCaretInstalled = YES;
}
static void WeTypeCleanCaretImage(const struct mach_header *header, intptr_t slide) {
    dispatch_async(dispatch_get_main_queue(), ^{ WeTypeCleanInstallCaret(); });
}
%ctor {
    _dyld_register_func_for_add_image(WeTypeCleanCaretImage);
    dispatch_async(dispatch_get_main_queue(), ^{ WeTypeCleanInstallCaret(); });
}
