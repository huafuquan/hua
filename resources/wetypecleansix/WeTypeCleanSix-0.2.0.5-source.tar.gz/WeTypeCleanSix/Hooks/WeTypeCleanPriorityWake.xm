#import <UIKit/UIKit.h>
#import <notify.h>
#import <time.h>
#import <objc/runtime.h>
#include "../Priority/WeTypeCleanSixPriorityPolicy.h"

// UIKit lifecycle is main-thread owned. Per-controller visibility; process-wide
// leading-edge throttle. Duplicate opens within five seconds are dropped, not
// deferred: no timer, trailing notification, layout/input/candidate callback.
static char WTSVisibleKey;
static void WTSPriorityWake(void) {
    static WTSWakeGate gate;
    if (!WTSAdmitWake(&gate, clock_gettime_nsec_np(CLOCK_MONOTONIC))) return;
    (void)notify_post("com.hua.wetypecleansix.priority.keyboard-open");
}
%group WTSPriorityKeyboardOnly
%hook UIInputViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    bool visible = [objc_getAssociatedObject(self, &WTSVisibleKey) boolValue];
    if (!WTSVisibilityAppeared(&visible)) return;
    objc_setAssociatedObject(self, &WTSVisibleKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    WTSPriorityWake();
}
- (void)viewDidDisappear:(BOOL)animated {
    %orig;
    objc_setAssociatedObject(self, &WTSVisibleKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
%end
%end
%ctor {
    @autoreleasepool {
        if ([NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.tencent.wetype.keyboard"]) {
            %init(WTSPriorityKeyboardOnly);
        }
    }
}
