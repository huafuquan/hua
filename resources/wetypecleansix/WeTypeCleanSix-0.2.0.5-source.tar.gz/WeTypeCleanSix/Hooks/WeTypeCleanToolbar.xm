#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <mach-o/dyld.h>
#import <dispatch/dispatch.h>
#import "WeTypeCleanToolbarGeometry.h"
#include <string.h>

// Only recovered ivars are read. Never enumerate a guessed button subtree.
static id WeTypeCleanSixObject(id obj, const char *name, Class expected) {
    if (!obj || !expected) return nil;
    Ivar ivar = class_getInstanceVariable(object_getClass(obj), name);
    const char *type = ivar ? ivar_getTypeEncoding(ivar) : NULL;
    if (!type || type[0] != '@') return nil;
    id value = object_getIvar(obj, ivar);
    return [value isKindOfClass:expected] ? value : nil;
}
static BOOL WeTypeCleanSixBusy(id obj, const char *name) {
    Ivar ivar = obj ? class_getInstanceVariable(object_getClass(obj), name) : NULL;
    const char *type = ivar ? ivar_getTypeEncoding(ivar) : NULL;
    if (!type || (strcmp(type, "B") && strcmp(type, "c"))) {
        return YES;
    }
    ptrdiff_t offset = ivar_getOffset(ivar);
    if (offset < 0 || (size_t)offset >= class_getInstanceSize(object_getClass(obj))) return YES;
    const unsigned char *bytes = (const unsigned char *)(__bridge const void *)obj;
    return bytes[offset] != 0;
}
static BOOL WeTypeCleanSixVisible(UIView *view, UIView *root) {
    if (!view || ![view isDescendantOfView:root]) return NO;
    for (UIView *v = view; v; v = v.superview) {
        CGAffineTransform t = v.transform;
        if (v.hidden || v.alpha <= .01 || t.a != 1 || t.b != 0 || t.c != 0 || t.d != 1) return NO;
        // Native bottom-panel restoration translates layers vertically. Translation
        // preserves sizes and relative row geometry; scale/rotation still fail closed.
        if (v == root) return YES;
    }
    return NO;
}
static char WeTypeCleanSixToolbarGuard;
static Class WeTypeCleanSixMainClass, WeTypeCleanSixTopClass, WeTypeCleanSixFunctionClass;

static void WeTypeCleanSixReflow(UIView *trigger) {
    if (!NSThread.isMainThread || !WeTypeCleanSixMainClass) return;
    UIView *main = trigger;
    while (main && ![main isKindOfClass:WeTypeCleanSixMainClass]) main = main.superview;
    if (!main || objc_getAssociatedObject(main, &WeTypeCleanSixToolbarGuard)) return;
    UIView *top = WeTypeCleanSixObject(main, "_topBar", WeTypeCleanSixTopClass);
    UIView *toolbar = WeTypeCleanSixObject(top, "_toolBar", WeTypeCleanSixFunctionClass);
    if (!top || !toolbar || top.superview != main || toolbar.superview != top ||
        !WeTypeCleanSixVisible(toolbar, main)) return;
    const char *mainFlags[] = {"_logoAndToolBarHidden", "_showingCandidateExpandView", "_splitEnabled", "_separateEnabled", "_hidesTopbar"};
    for (unsigned i = 0; i < sizeof(mainFlags)/sizeof(*mainFlags); ++i)
        if (WeTypeCleanSixBusy(main, mainFlags[i])) { return; }
    // _candidateViewActive is capability/activation, YES even with zero words.
    // _prefersVoiceInputControl is policy. Neither identifies visible content.
    const char *contentNames[] = {"_candidateView", "_businessCandidateView", "_voiceInputControl", "_addHotWordEntranceView"};
    for (unsigned i = 0; i < sizeof(contentNames)/sizeof(*contentNames); ++i) {
        UIView *content = WeTypeCleanSixObject(top, contentNames[i], UIView.class);
        if (WeTypeCleanSixVisible(content, main) && !CGRectIsEmpty(content.bounds)) {
            return;
        }
    }
    const char *topFlags[] = { "_hidesContent", "_expanded", "_splitEnabled", "_overlayVisible"};
    for (unsigned i = 0; i < sizeof(topFlags)/sizeof(*topFlags); ++i)
        if (WeTypeCleanSixBusy(top, topFlags[i])) { return; }
    if (WeTypeCleanSixBusy(toolbar, "_editing") ||
        WeTypeCleanSixBusy(toolbar, "_voiceInputFocused")) { return; }
    UIScrollView *scroll = WeTypeCleanSixObject(toolbar, "_scrollView", UIScrollView.class);
    NSOrderedSet *buttons = WeTypeCleanSixObject(toolbar, "_buttons", NSOrderedSet.class);
    if (!scroll || !buttons || scroll.superview != toolbar || scroll.dragging || scroll.decelerating ||
        !WeTypeCleanSixVisible(scroll, main)) return;
    UIView *logo = WeTypeCleanSixObject(main, "_customizedLogoButton", UIView.class);
    if (!WeTypeCleanSixVisible(logo, main) || logo.superview != main || CGRectIsEmpty(logo.bounds))
        logo = WeTypeCleanSixObject(main, "_logoButton", UIView.class);
    if (!WeTypeCleanSixVisible(logo, main) || logo.superview != main || CGRectIsEmpty(logo.bounds)) logo = nil;
    NSMutableArray<UIView *> *views = [NSMutableArray array];
    if (logo) [views addObject:logo];
    for (id value in buttons) {
        if (![value isKindOfClass:UIView.class]) return;
        UIView *button = value;
        if (!WeTypeCleanSixVisible(button, main) || CGRectIsEmpty(button.bounds)) continue;
        if (button.superview != scroll && button.superview != toolbar) { return; }
        if (![views containsObject:button]) [views addObject:button];
    }
    NSUInteger count = views.count;
    if (!count || count > 64) return;
    double widths[64], positions[64], visibleLeft[64], visibleWidths[64], topInset = 0;
    CGRect frames[64];
    CGRect row = [top convertRect:top.bounds toView:main];
    double left = MAX(CGRectGetMinX(main.bounds) + main.safeAreaInsets.left, CGRectGetMinX(row));
    double right = MIN(CGRectGetMaxX(main.bounds) - main.safeAreaInsets.right, CGRectGetMaxX(row));
    for (NSUInteger i = 0; i < count; ++i) {
        UIView *v = views[i];
        frames[i] = [v.superview convertRect:v.frame toView:main];
        widths[i] = CGRectGetWidth(frames[i]);
        // Some native button classes expose a smaller backgroundLayer; use its
        // actual model rect, never infer the circle from the hit target width.
        CGRect visible = v.bounds;
        Method bgMethod = class_getInstanceMethod(object_getClass(v), sel_registerName("backgroundLayer"));
        if (bgMethod && method_getNumberOfArguments(bgMethod) == 2) {
            char type[32]; method_getReturnType(bgMethod, type, sizeof(type));
            if (type[0] != '@') return;
            id layer = ((id (*)(id, SEL))method_getImplementation(bgMethod))(v, sel_registerName("backgroundLayer"));
            if (![layer isKindOfClass:CALayer.class] || ![(CALayer *)layer superlayer]) return;
            visible = [v.layer convertRect:[(CALayer *)layer bounds] fromLayer:layer];
        } else {
            // RE: WBUIFactory.logoButton sets isRounded; WBButton's visible
            // background fills bounds. Reject unknown classes, no guessed subtree.
            Class nativeButton = objc_getClass("WBButton");
            if (!nativeButton || ![v isKindOfClass:nativeButton]) return;
        }
        if (CGRectIsEmpty(visible) || !CGRectContainsRect(v.bounds, visible)) return;
        visibleLeft[i] = CGRectGetMinX(visible)-CGRectGetMinX(v.bounds);
        visibleWidths[i] = CGRectGetWidth(visible);
        CGRect visibleMain = [v convertRect:visible toView:main];
        double inset = CGRectGetMinY(visibleMain)-CGRectGetMinY(row);
        if (!isfinite(inset) || inset < 0) return;
        if (i == 0) topInset = inset;
        // End backgrounds must share top whitespace to meet both edge equalities.
        if ((i == 0 || i == count-1) && fabs(inset-topInset) > .5) return;
        if (CGRectGetHeight(frames[i]) <= 0 || !isfinite(CGRectGetHeight(frames[i])) ||
            CGRectGetMinY(frames[i]) < CGRectGetMinY(row) - .5 ||
            CGRectGetMaxY(frames[i]) > CGRectGetMaxY(row) + .5) return;
    }
    // Overflow keeps the native scrolling layout. Do not compress hit targets.
    if (!WeTypeCleanSixToolbarPositions(left, right, widths, visibleLeft, visibleWidths, count, topInset, 0.0, positions)) { return; }
    for (NSUInteger i = 0; i < count; ++i) frames[i].origin.x = positions[i];
    double toolbarLeft = logo ? CGRectGetMaxX(frames[0]) : left;
    if (toolbarLeft >= right) return;
    CGRect toolbarRow = CGRectMake(toolbarLeft, row.origin.y, right-toolbarLeft, row.size.height);
    // The native direct-child arrow remains above the scroll view. Its gap is
    // outside the scroll hit region, so neither parent covers the logo/arrow.
    double scrollRight = right;
    for (NSUInteger i = 0; i < count; ++i)
        if (views[i] != logo && views[i].superview == toolbar)
            scrollRight = MIN(scrollRight, CGRectGetMinX(frames[i]));
    if (scrollRight < toolbarLeft) return;
    objc_setAssociatedObject(main, &WeTypeCleanSixToolbarGuard, main, OBJC_ASSOCIATION_ASSIGN);
    @try {
        CGRect frame = [main convertRect:toolbarRow toView:top];
        if (!CGRectEqualToRect(toolbar.frame, frame)) toolbar.frame = frame;
        CGRect scrollRow = CGRectMake(toolbarLeft, row.origin.y, scrollRight-toolbarLeft, row.size.height);
        frame = [main convertRect:scrollRow toView:toolbar];
        if (!CGRectEqualToRect(scroll.frame, frame)) scroll.frame = frame;
        if (!UIEdgeInsetsEqualToEdgeInsets(scroll.contentInset, UIEdgeInsetsZero)) scroll.contentInset = UIEdgeInsetsZero;
        if (!CGPointEqualToPoint(scroll.contentOffset, CGPointZero)) scroll.contentOffset = CGPointZero;
        if (!CGSizeEqualToSize(scroll.contentSize, scroll.bounds.size)) scroll.contentSize = scroll.bounds.size;
        for (NSUInteger i = 0; i < count; ++i) {
            UIView *v = views[i];
            frame = [main convertRect:frames[i] toView:v.superview];
            if (!CGRectEqualToRect(v.frame, frame)) v.frame = frame;
        }
        
    } @finally {
        objc_setAssociatedObject(main, &WeTypeCleanSixToolbarGuard, nil, OBJC_ASSOCIATION_ASSIGN);
    }
}

// Only normal native layout exits apply synchronous static geometry.
%group WeTypeCleanSixToolbarMain
%hook WBMainInputView
- (void)layoutSubviews {
    %orig;
    WeTypeCleanSixReflow((UIView *)self);
}
%end
%end
%group WeTypeCleanSixToolbarTop
%hook WBTopBar
- (void)layoutSubviews {
    %orig;
    WeTypeCleanSixReflow((UIView *)self);
}
%end
%end
%group WeTypeCleanSixToolbarFunction
%hook WBFunctionToolBar
- (void)layoutSubviews {
    %orig;
    WeTypeCleanSixReflow((UIView *)self);
}
%end
%end
static unsigned WeTypeCleanSixToolbarInstalled, WeTypeCleanSixToolbarPending, WeTypeCleanSixToolbarRounds;
static BOOL WeTypeCleanSixToolbarMethod(Class cls) {
    Method m = cls ? class_getInstanceMethod(cls, @selector(layoutSubviews)) : NULL;
    if (!m || method_getNumberOfArguments(m) != 2) return NO;
    char type[16]; method_getReturnType(m, type, sizeof(type));
    return !strcmp(type, "v");
}
static void WeTypeCleanSixInstallToolbar(void) {
    WeTypeCleanSixMainClass = objc_getClass("WBMainInputView");
    if (!(WeTypeCleanSixToolbarInstalled & 1) && WeTypeCleanSixToolbarMethod(WeTypeCleanSixMainClass)) {
        %init(WeTypeCleanSixToolbarMain, WBMainInputView = WeTypeCleanSixMainClass);
        WeTypeCleanSixToolbarInstalled |= 1;
    }
    WeTypeCleanSixTopClass = objc_getClass("WBTopBar");
    if (!(WeTypeCleanSixToolbarInstalled & 2) && WeTypeCleanSixToolbarMethod(WeTypeCleanSixTopClass)) {
        %init(WeTypeCleanSixToolbarTop, WBTopBar = WeTypeCleanSixTopClass);
        WeTypeCleanSixToolbarInstalled |= 2;
    }
    WeTypeCleanSixFunctionClass = objc_getClass("WBFunctionToolBar");
    if (!(WeTypeCleanSixToolbarInstalled & 4) && WeTypeCleanSixToolbarMethod(WeTypeCleanSixFunctionClass)) {
        %init(WeTypeCleanSixToolbarFunction, WBFunctionToolBar = WeTypeCleanSixFunctionClass);
        WeTypeCleanSixToolbarInstalled |= 4;
    }
}
static void WeTypeCleanSixToolbarImageWork(void *context) {
    (void)context;
    __atomic_store_n(&WeTypeCleanSixToolbarPending, 0u, __ATOMIC_RELEASE);
    @autoreleasepool { WeTypeCleanSixInstallToolbar(); }
}
static void WeTypeCleanSixToolbarImageAdded(const struct mach_header *header, intptr_t slide) {
    (void)header; (void)slide;
    if (!__atomic_exchange_n(&WeTypeCleanSixToolbarPending, 1u, __ATOMIC_ACQ_REL))
        dispatch_async_f(dispatch_get_main_queue(), NULL, WeTypeCleanSixToolbarImageWork);
}
static void WeTypeCleanSixToolbarRetry(void *context) {
    (void)context;
    @autoreleasepool { WeTypeCleanSixInstallToolbar(); }
    if (WeTypeCleanSixToolbarInstalled != 7u && ++WeTypeCleanSixToolbarRounds < 32u)
        dispatch_after_f(dispatch_time(DISPATCH_TIME_NOW, 250 * NSEC_PER_MSEC), dispatch_get_main_queue(), NULL, WeTypeCleanSixToolbarRetry);
}
%ctor {
    @autoreleasepool {
        if (NSThread.isMainThread) WeTypeCleanSixInstallToolbar();
        dispatch_async_f(dispatch_get_main_queue(), NULL, WeTypeCleanSixToolbarRetry);
        _dyld_register_func_for_add_image(WeTypeCleanSixToolbarImageAdded);
    }
}
