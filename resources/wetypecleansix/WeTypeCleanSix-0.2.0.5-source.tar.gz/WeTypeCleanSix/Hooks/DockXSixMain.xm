#import "DockXSixPrivate.h"
#import "DockXSixCollectionView.h"
#import <objc/runtime.h>

static char dockxsix_collectionKey;
static DockXSixCollectionView *dockxsix_collection(UIKeyboardDockView *dock) {
    return objc_getAssociatedObject(dock, &dockxsix_collectionKey);
}
static void dockxsix_updateDock(UIKeyboardDockView *dock) {
    DockXSixCollectionView *collection = dockxsix_collection(dock);
    if (!collection) return;
    UIInterfaceOrientation orientation = dock.window.windowScene.interfaceOrientation;
    BOOL hidden = UIInterfaceOrientationIsLandscape(orientation);
    Class cls = objc_getClass("UIKeyboardImpl");
    UIKeyboardImpl *keyboard = [cls respondsToSelector:@selector(activeInstance)] ? [cls activeInstance] : nil;
    if ([keyboard respondsToSelector:@selector(isUsingDictationLayout)] && [keyboard isUsingDictationLayout]) hidden = YES;
    if ([dock respondsToSelector:@selector(centerDockItem)]) {
        UIKeyboardDockItem *item = dock.centerDockItem;
        if ([item respondsToSelector:@selector(view)] && item.view && !item.view.hidden) hidden = YES;
    }
    collection.hidden = hidden;
    [collection dockxsix_updateAppearance];
}

%group DockXSixDock
%hook UIKeyboardDockView
- (instancetype)initWithFrame:(CGRect)frame {
    UIKeyboardDockView *dock = %orig;
    if (dock && !dockxsix_collection(dock)) {
        DockXSixCollectionView *collection = [DockXSixCollectionView new];
        collection.translatesAutoresizingMaskIntoConstraints = NO;
        objc_setAssociatedObject(dock, &dockxsix_collectionKey, collection, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        [dock addSubview:collection];
        // Same real Dock anchors as DockX, fixed screenshot geometry in points.
        [NSLayoutConstraint activateConstraints:@[
            [collection.leadingAnchor constraintEqualToAnchor:dock.leadingAnchor constant:30],
            [collection.trailingAnchor constraintEqualToAnchor:dock.trailingAnchor constant:-30],
            [collection.heightAnchor constraintEqualToConstant:32],
            [collection.bottomAnchor constraintEqualToAnchor:dock.bottomAnchor constant:-27]
        ]];
        dockxsix_updateDock(dock);
    }
    return dock;
}
- (void)layoutSubviews {
    %orig;
    dockxsix_updateDock(self);
}
%end
%end

%ctor {
    @autoreleasepool {
        Class dock = objc_getClass("UIKeyboardDockView");
        if (dock && class_getInstanceMethod(dock, @selector(initWithFrame:)) && class_getInstanceMethod(dock, @selector(layoutSubviews))) {
            %init(DockXSixDock);
        }
    }
}
