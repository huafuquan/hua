#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <mach-o/dyld.h>
#import <dispatch/dispatch.h>

// Recovered KeyboardX host/scene behavior, with fixed radius and no preferences.
static unsigned int wetypeclean_outerHooks;
static unsigned int wetypeclean_outerPending;
static unsigned int wetypeclean_outerRounds;

static void wetypeclean_applyOuter(UIView *view) {
    CALayer *layer = view.layer;
    if (!layer) return;
    layer.cornerRadius = 30.0;
    layer.masksToBounds = YES;
    if ([layer respondsToSelector:@selector(setCornerCurve:)]) {
        layer.cornerCurve = kCACornerCurveContinuous;
    }
    CGFloat maxY = CGRectGetMaxY(view.frame);
    CGFloat height = CGRectGetHeight(UIScreen.mainScreen.bounds);
    layer.maskedCorners = maxY < height - 10.0
        ? (kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner |
           kCALayerMinXMaxYCorner | kCALayerMaxXMaxYCorner)
        : (kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner);
}

%group WeTypeCleanOuterHost
%hook UIInputSetHostView
- (void)layoutSubviews {
    %orig;
    wetypeclean_applyOuter((UIView *)self);
}
%end
%end

%group WeTypeCleanOuterScene
%hook UIKeyboardSceneDelegate
- (void)updateRenderConfigForResponder:(id)responder {
    %orig;
    SEL selector = @selector(containerView);
    if ([(id)self respondsToSelector:selector]) {
        id container = ((id (*)(id, SEL))objc_msgSend)((id)self, selector);
        if ([container respondsToSelector:@selector(setNeedsLayout)]) {
            [container setNeedsLayout];
        }
    }
}
%end
%end

// Serialize hook installation on the main queue. Handle UIKit classes that
// arrive after the dylib constructor; dyld callbacks never install hooks inline.
static void wetypeclean_registerOuter(void) {
    if (!(wetypeclean_outerHooks & 1u)) {
        Class host = objc_getClass("UIInputSetHostView");
        if (host && class_getInstanceMethod(host, @selector(layoutSubviews))) {
            %init(WeTypeCleanOuterHost, UIInputSetHostView = host);
            wetypeclean_outerHooks |= 1u;
        }
    }
    if (!(wetypeclean_outerHooks & 2u)) {
        Class scene = objc_getClass("UIKeyboardSceneDelegate");
        if (scene && class_getInstanceMethod(scene, @selector(updateRenderConfigForResponder:))) {
            %init(WeTypeCleanOuterScene, UIKeyboardSceneDelegate = scene);
            wetypeclean_outerHooks |= 2u;
        }
    }
}

static void wetypeclean_outerImageWork(void *context) {
    (void)context;
    __atomic_store_n(&wetypeclean_outerPending, 0u, __ATOMIC_RELEASE);
    @autoreleasepool { wetypeclean_registerOuter(); }
}

static void wetypeclean_outerImageAdded(const struct mach_header *header, intptr_t slide) {
    (void)header; (void)slide;
    if (!__atomic_exchange_n(&wetypeclean_outerPending, 1u, __ATOMIC_ACQ_REL)) {
        dispatch_async_f(dispatch_get_main_queue(), NULL, wetypeclean_outerImageWork);
    }
}

static void wetypeclean_outerRetry(void *context) {
    (void)context;
    @autoreleasepool { wetypeclean_registerOuter(); }
    if (wetypeclean_outerHooks != 3u && ++wetypeclean_outerRounds < 32u) {
        dispatch_after_f(dispatch_time(DISPATCH_TIME_NOW, 250 * NSEC_PER_MSEC),
                         dispatch_get_main_queue(), NULL, wetypeclean_outerRetry);
    }
}

%ctor {
    @autoreleasepool {
        if (NSThread.isMainThread) wetypeclean_registerOuter();
        dispatch_async_f(dispatch_get_main_queue(), NULL, wetypeclean_outerRetry);
        _dyld_register_func_for_add_image(wetypeclean_outerImageAdded);
    }
}
