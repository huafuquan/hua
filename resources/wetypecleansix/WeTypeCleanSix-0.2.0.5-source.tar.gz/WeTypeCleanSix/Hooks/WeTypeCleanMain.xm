#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import <string.h>
#import "WeTypeCleanPrivate.h"

static const double wetypeclean_radius = 18.0;
static Ivar wetypeclean_radiusIvar;

static void wetypeclean_applyRadius(WBKeyView *view) {
    if (![view respondsToSelector:@selector(backgroundLayer)]) return;
    CALayer *background = [view backgroundLayer];
    if (!background) return;
    background.cornerRadius = wetypeclean_radius;
    background.masksToBounds = YES;
    background.mask = nil;
}

%group WeTypeCleanKeys
%hook WBKeyViewItem
- (double)cornerRadius {
    return wetypeclean_radius;
}
- (void)parseBaseProperties {
    %orig;
    // The original writes _cornerRadius directly after parsing. Validate the ABI
    // and ivar bounds before preserving that behavior for supported versions.
    if (wetypeclean_radiusIvar) {
        unsigned char *bytes = (unsigned char *)(__bridge void *)self;
        double radius = wetypeclean_radius;
        memcpy(bytes + ivar_getOffset(wetypeclean_radiusIvar), &radius, sizeof(radius));
    }
}
%end

%hook WBKeyView
- (void)layoutSubviews {
    %orig;
    wetypeclean_applyRadius(self);
}
- (void)updateBackgroundColor {
    %orig;
    wetypeclean_applyRadius(self);
}
%end
%end

%group WeTypeCleanCandidates
%hook WBCandidateCell
- (void)renderCandidateWord:(id)word focusedStyle:(BOOL)focused atIndex:(NSInteger)index {
    %orig(word, NO, index);
}
%end
%end

%ctor {
    @autoreleasepool {
        Class item = objc_getClass("WBKeyViewItem");
        Class key = objc_getClass("WBKeyView");
        if (item && key && class_getInstanceMethod(item, @selector(cornerRadius)) &&
            class_getInstanceMethod(item, @selector(parseBaseProperties)) &&
            class_getInstanceMethod(key, @selector(layoutSubviews)) &&
            class_getInstanceMethod(key, @selector(updateBackgroundColor))) {
            Ivar ivar = class_getInstanceVariable(item, "_cornerRadius");
            if (ivar && strcmp(ivar_getTypeEncoding(ivar), @encode(double)) == 0 &&
                ivar_getOffset(ivar) >= 0 &&
                (size_t)ivar_getOffset(ivar) + sizeof(double) <= class_getInstanceSize(item)) {
                wetypeclean_radiusIvar = ivar;
            }
            %init(WeTypeCleanKeys);
        }
        Class candidate = objc_getClass("WBCandidateCell");
        if (candidate && class_getInstanceMethod(candidate, @selector(renderCandidateWord:focusedStyle:atIndex:))) {
            %init(WeTypeCleanCandidates);
        }
    }
}
