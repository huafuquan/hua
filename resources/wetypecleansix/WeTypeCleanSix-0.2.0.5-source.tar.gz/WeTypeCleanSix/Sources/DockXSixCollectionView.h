#pragma once
#import <UIKit/UIKit.h>
// Reduced from DockX's DXCell/DXCollectionView architecture; see NOTICE.
@interface DockXSixCell : UICollectionViewCell
@property(nonatomic, strong, readonly) UIButton *dockxsix_button;
@end
@interface DockXSixCollectionView : UICollectionView <UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>
- (void)dockxsix_updateAppearance;
@end
