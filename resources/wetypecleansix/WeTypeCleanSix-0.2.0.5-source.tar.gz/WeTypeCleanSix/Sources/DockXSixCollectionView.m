#import "DockXSixCollectionView.h"
#import "DockXSixPrivate.h"
#import <objc/runtime.h>
#import <notify.h>
#import <dispatch/dispatch.h>

static void dockxsix_lightImpact(void *context) {
    @autoreleasepool {
        UIImpactFeedbackGenerator *feedback = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
        [feedback impactOccurred];
    }
}

static void dockxsix_kayokoShow(void *context) {
    notify_post("codes.aurora.kayoko.core.show");
}
static void dockxsix_showHistory(void) {
    // Original keyboard enhancement: 0x675c, 0x67a4, 0x67f8, 0x6f9c.
    // notify_post cannot detect receivers. Each supported entry is requested.
    notify_post("me.tomt000.copylog.showView");
    notify_post("com.squidforce.copyvault/show");
    notify_post("codes.aurora.kayoko.preferences.reload");
    dispatch_after_f(dispatch_time(DISPATCH_TIME_NOW, 50 * NSEC_PER_MSEC),
        dispatch_get_main_queue(), NULL, dockxsix_kayokoShow);
}

static UIKeyboardImpl *dockxsix_keyboard(void) {
    Class cls = objc_getClass("UIKeyboardImpl");
    return [cls respondsToSelector:@selector(activeInstance)] ? [cls activeInstance] : nil;
}
static id dockxsix_delegate(UIKeyboardImpl *keyboard) {
    // Uploaded DockX 2.5.4 bf6c uses inputDelegate, unlike public 2.4.4.
    return [keyboard respondsToSelector:@selector(inputDelegate)] ? keyboard.inputDelegate : nil;
}
static void dockxsix_clear(UIKeyboardImpl *keyboard) {
    if ([keyboard respondsToSelector:@selector(clearTransientState)]) [keyboard clearTransientState];
    if ([keyboard respondsToSelector:@selector(clearAnimations)]) [keyboard clearAnimations];
    if ([keyboard respondsToSelector:@selector(setCaretBlinks:)]) [keyboard setCaretBlinks:YES];
}
static void dockxsix_selectAll(id delegate, UIKeyboardImpl *keyboard) {
    if ([delegate respondsToSelector:@selector(selectAll:)]) [delegate selectAll:nil];
    else if ([delegate respondsToSelector:@selector(selectAll)]) {
        [delegate selectAll];
        dockxsix_clear(keyboard);
    }
}

@implementation DockXSixCell
- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.contentView.backgroundColor = UIColor.clearColor;
        _dockxsix_button = [UIButton buttonWithType:UIButtonTypeSystem];
        _dockxsix_button.translatesAutoresizingMaskIntoConstraints = NO;
        _dockxsix_button.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightRegular];
        [self.contentView addSubview:_dockxsix_button];
        [NSLayoutConstraint activateConstraints:@[
            [_dockxsix_button.topAnchor constraintEqualToAnchor:self.contentView.topAnchor],
            [_dockxsix_button.bottomAnchor constraintEqualToAnchor:self.contentView.bottomAnchor],
            [_dockxsix_button.leadingAnchor constraintEqualToAnchor:self.contentView.leadingAnchor],
            [_dockxsix_button.trailingAnchor constraintEqualToAnchor:self.contentView.trailingAnchor]
        ]];
    }
    return self;
}
@end

@implementation DockXSixCollectionView
- (instancetype)init {
    UICollectionViewFlowLayout *flow = [UICollectionViewFlowLayout new];
    flow.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    flow.minimumInteritemSpacing = 0;
    flow.minimumLineSpacing = 0;
    flow.sectionInset = UIEdgeInsetsZero;
    if ((self = [super initWithFrame:CGRectZero collectionViewLayout:flow])) {
        self.dataSource = self;
        self.delegate = self;
        self.scrollEnabled = NO;
        self.showsHorizontalScrollIndicator = NO;
        self.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        self.semanticContentAttribute = UISemanticContentAttributeForceLeftToRight;
        self.layer.cornerRadius = 16;
        self.clipsToBounds = YES;
        [self registerClass:DockXSixCell.class forCellWithReuseIdentifier:@"DockXSixCell"];
    }
    return self;
}
- (NSInteger)collectionView:(UICollectionView *)view numberOfItemsInSection:(NSInteger)section { return 6; }
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)view cellForItemAtIndexPath:(NSIndexPath *)path {
    DockXSixCell *cell = [view dequeueReusableCellWithReuseIdentifier:@"DockXSixCell" forIndexPath:path];
    NSArray *titles = @[@"剪切", @"全选", @"复制", @"粘贴", @"历史", @"收起"];
    UIButton *button = cell.dockxsix_button;
    [button setTitle:titles[path.item] forState:UIControlStateNormal];
    button.accessibilityLabel = titles[path.item];
    button.tag = path.item;
    [button removeTarget:self action:@selector(dockxsix_pressed:) forControlEvents:UIControlEventTouchUpInside];
    [button addTarget:self action:@selector(dockxsix_pressed:) forControlEvents:UIControlEventTouchUpInside];
    [self dockxsix_applyColorToButton:button];
    return cell;
}
- (CGSize)collectionView:(UICollectionView *)view layout:(UICollectionViewLayout *)layout sizeForItemAtIndexPath:(NSIndexPath *)path {
    return CGSizeMake(CGRectGetWidth(self.bounds) / 6.0, 32);
}
- (void)layoutSubviews {
    UICollectionViewFlowLayout *flow = (UICollectionViewFlowLayout *)self.collectionViewLayout;
    CGSize expected = CGSizeMake(CGRectGetWidth(self.bounds) / 6.0, 32);
    if (!CGSizeEqualToSize(flow.itemSize, expected)) {
        flow.itemSize = expected;
        [flow invalidateLayout];
    }
    [super layoutSubviews];
    [self dockxsix_updateAppearance];
}
- (BOOL)dockxsix_isDark {
    id delegate = dockxsix_delegate(dockxsix_keyboard());
    if ([delegate respondsToSelector:@selector(keyboardAppearance)]) {
        UIKeyboardAppearance appearance = [(id<UITextInputTraits>)delegate keyboardAppearance];
        if (appearance == UIKeyboardAppearanceDark) return YES;
        if (appearance == UIKeyboardAppearanceLight) return NO;
    }
    return self.traitCollection.userInterfaceStyle == UIUserInterfaceStyleDark;
}
- (void)dockxsix_applyColorToButton:(UIButton *)button {
    UIColor *text = [self dockxsix_isDark] ? UIColor.whiteColor : UIColor.blackColor;
    [button setTitleColor:text forState:UIControlStateNormal];
    button.tintColor = text;
}
- (void)dockxsix_updateAppearance {
    // Screenshot return-key samples. No unsupported third-party key traversal.
    BOOL dark = [self dockxsix_isDark];
    self.backgroundColor = dark ? [UIColor colorWithRed:60/255.0 green:60/255.0 blue:60/255.0 alpha:0.8]
        : [UIColor colorWithRed:183/255.0 green:187/255.0 blue:196/255.0 alpha:0.6];
    for (DockXSixCell *cell in self.visibleCells) [self dockxsix_applyColorToButton:cell.dockxsix_button];
}
- (void)traitCollectionDidChange:(UITraitCollection *)previous {
    [super traitCollectionDidChange:previous];
    [self dockxsix_updateAppearance];
}
- (void)dockxsix_pressed:(UIButton *)sender {
    // One light impact per button invocation, including actions with no delegate.
    if ([NSThread isMainThread]) dockxsix_lightImpact(NULL);
    else dispatch_async_f(dispatch_get_main_queue(), NULL, dockxsix_lightImpact);
    if (sender.tag == 4) {
        dockxsix_showHistory();
        return;
    }
    UIKeyboardImpl *keyboard = dockxsix_keyboard();
    id delegate = dockxsix_delegate(keyboard);
    if (sender.tag == 5) {
        if ([keyboard respondsToSelector:@selector(dismissKeyboard)]) [keyboard dismissKeyboard];
        return;
    }
    if (!delegate) return;
    switch (sender.tag) {
        case 0: [self dockxsix_copyOrCut:YES delegate:delegate keyboard:keyboard]; break;
        case 1: dockxsix_selectAll(delegate, keyboard); break;
        case 2: [self dockxsix_copyOrCut:NO delegate:delegate keyboard:keyboard]; break;
        case 3: [self dockxsix_paste:delegate keyboard:keyboard]; break;
    }
}
- (void)dockxsix_copyOrCut:(BOOL)cut delegate:(id)delegate keyboard:(UIKeyboardImpl *)keyboard {
    // A nil/unsupported selection is unknown, not proof of an empty range.
    // Preserve standard copy/cut behavior in that case.
    if ([delegate respondsToSelector:@selector(selectedTextRange)]) {
        UITextRange *selection = [(id<UITextInput>)delegate selectedTextRange];
        if (selection && [selection respondsToSelector:@selector(isEmpty)] && selection.isEmpty) {
            dockxsix_selectAll(delegate, keyboard);
        }
    }
    SEL action = cut ? @selector(cut:) : @selector(copy:);
    if ([delegate respondsToSelector:action]) {
        if (cut) [delegate cut:nil]; else [delegate copy:nil];
        return;
    }
    if (![delegate respondsToSelector:@selector(selectedTextRange)] || ![delegate respondsToSelector:@selector(textInRange:)]) return;
    id<UITextInput> input = delegate;
    UITextRange *range = input.selectedTextRange;
    NSString *text = range ? [input textInRange:range] : nil;
    // Selection expansion happens only for a confirmed empty range above.
    // A nil range or an unreadable nonempty selection must not select all.
    // Protect unsupported/empty input; do not delete a character with no selection.
    if (text.length == 0) return;
    UIPasteboard.generalPasteboard.string = text;
    if (cut && [keyboard respondsToSelector:@selector(deleteFromInput)]) [keyboard deleteFromInput];
    dockxsix_clear(keyboard);
}
- (void)dockxsix_paste:(id)delegate keyboard:(UIKeyboardImpl *)keyboard {
    if ([delegate respondsToSelector:@selector(paste:)]) { [delegate paste:nil]; return; }
    if (![delegate respondsToSelector:@selector(selectedTextRange)]) return;
    NSString *text = UIPasteboard.generalPasteboard.string;
    // DockX 2.5.4 cb44-cb80 uses the inputDelegateManager (not the old direct insert).
    id manager = [keyboard respondsToSelector:@selector(inputDelegateManager)] ? keyboard.inputDelegateManager : nil;
    if (text && [manager respondsToSelector:@selector(insertText:)]) {
        [manager insertText:text];
        if ([manager respondsToSelector:@selector(clearForwardingInputDelegateAndResign:)]) [manager clearForwardingInputDelegateAndResign:YES];
        if ([keyboard respondsToSelector:@selector(updateReturnKey)]) [keyboard updateReturnKey];
    }
    dockxsix_clear(keyboard);
}
@end
