#ifndef WETYPECLEANSIX_TOOLBAR_GEOMETRY_H
#define WETYPECLEANSIX_TOOLBAR_GEOMETRY_H
#include <stddef.h>
#include <math.h>
/* visible[i]: offset and width of actual background within unchanged hit frame.
 * Equal center pitch; symmetric visible outer inset equals measured top inset.
 * Validate everything before publishing output. Overflow preserves native UI. */
static inline int WeTypeCleanSixToolbarPositions(double left, double right,
    const double *widths, const double *visibleLeft, const double *visibleWidths,
    size_t count, double inset, double minimumGap, double *positions) {
    if (!count || count > 64 || !widths || !visibleLeft || !visibleWidths || !positions ||
        !isfinite(left) || !isfinite(right) || right <= left || !isfinite(inset) || inset < 0 ||
        !isfinite(minimumGap) || minimumGap < 0) return 0;
    for (size_t i=0;i<count;i++)
        if (!isfinite(widths[i]) || widths[i]<=0 || !isfinite(visibleLeft[i]) ||
            !isfinite(visibleWidths[i]) || visibleWidths[i]<=0 || visibleLeft[i]<0 ||
            visibleLeft[i]+visibleWidths[i]>widths[i]+1e-6) return 0;
    double first=left+inset-visibleLeft[0]+widths[0]/2;
    double last=right-inset-visibleLeft[count-1]-visibleWidths[count-1]+widths[count-1]/2;
    double pitch=count>1?(last-first)/(count-1):0;
    double out[64];
    if (count==1 && fabs(first-last)>1e-6) return 0;
    for (size_t i=0;i<count;i++) {
        out[i]=first+pitch*i-widths[i]/2;
        if (!isfinite(out[i]) || out[i]<left-1e-6 || out[i]+widths[i]>right+1e-6 ||
            (i && out[i]-out[i-1]-widths[i-1]<minimumGap-1e-6)) return 0;
    }
    for (size_t i=0;i<count;i++) positions[i]=out[i];
    return 1;
}
#endif
