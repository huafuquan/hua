#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
xcrun clang -Wall -Wextra -Werror tests/priority-policy.c -o "$tmp/policy"
"$tmp/policy"
echo 'policy assertions PASS'
xcrun clang -Wall -Wextra -Werror -fobjc-arc -fblocks -framework Foundation tests/priority-runtime.m -o "$tmp/runtime"
"$tmp/runtime"
python3 tests/wake-runtime.py "$tmp/wake.m"
xcrun clang -Wall -Wextra -Werror -fobjc-arc -fblocks -framework Foundation -I Priority "$tmp/wake.m" -o "$tmp/wake"
"$tmp/wake"
