"""Host shim for the actual Logos lifecycle bodies; no UIKit/device claim."""
from pathlib import Path
import sys
src=Path('Hooks/WeTypeCleanPriorityWake.xm').read_text()
shared=src[src.index('static char WTSVisibleKey;'):src.index('%group')]
methods=src[src.index('- (void)viewDidAppear:'):src.index('%end')]
methods=methods.replace('%orig;', '[super viewDidAppear:animated];',1)
methods=methods.replace('%orig;', '[super viewDidDisappear:animated];',1)
header='''#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#include <assert.h>
#include <stdint.h>
#include "WeTypeCleanSixPriorityPolicy.h"
static uint64_t testNow;
static int posts, appearCalls, disappearCalls;
#define clock_gettime_nsec_np(x) testNow
static int notify_post(const char *name) {
    assert(strcmp(name,"com.hua.wetypecleansix.priority.keyboard-open")==0);
    assert(appearCalls>0); posts++; return 0;
}
@interface WTSBase : NSObject
- (void)viewDidAppear:(BOOL)animated;
- (void)viewDidDisappear:(BOOL)animated;
@end
@implementation WTSBase
- (void)viewDidAppear:(BOOL)animated { (void)animated; appearCalls++; }
- (void)viewDidDisappear:(BOOL)animated { (void)animated; disappearCalls++; }
@end
@interface WTSKeyboard : WTSBase @end
'''
footer='''
@end
int main(void) { @autoreleasepool {
    WTSKeyboard *a=[WTSKeyboard new], *b=[WTSKeyboard new];
    testNow=0; [a viewDidAppear:YES]; assert(posts==1 && appearCalls==1);
    testNow=6000000000ull; [a viewDidAppear:YES];
    assert(posts==1 && appearCalls==2); // visible repeat never sends
    [a viewDidDisappear:YES]; assert(disappearCalls==1);
    [a viewDidAppear:YES]; assert(posts==2); // real reopen
    [b viewDidAppear:YES]; assert(posts==2); // process-wide throttle
    [b viewDidDisappear:YES]; testNow=10999999999ull;
    [b viewDidAppear:YES]; assert(posts==2);
    testNow=11000000000ull; [b viewDidAppear:YES]; assert(posts==2);
    // No trailing send just because window expired while still visible.
    [b viewDidDisappear:YES]; [b viewDidAppear:YES]; assert(posts==3);
    assert([objc_getAssociatedObject(b,&WTSVisibleKey) boolValue]);
    [b viewDidDisappear:NO]; assert(!objc_getAssociatedObject(b,&WTSVisibleKey));
    puts("actual wake hook bodies PASS: original calls, per-controller visibility, shared 5s throttle, exact boundary, no trailing sends");
} return 0; }
'''
Path(sys.argv[1]).write_text(header+shared+'\n@implementation WTSKeyboard\n'+methods+footer)
