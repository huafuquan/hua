#import <Foundation/Foundation.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <assert.h>
#include <errno.h>
static NSDictionary *fixtureInfo;
@interface NSDictionary (WTSTestFixture)
+ (instancetype)wts_dictionaryWithContentsOfFile:(NSString *)path;
@end
@implementation NSDictionary (WTSTestFixture)
+ (instancetype)wts_dictionaryWithContentsOfFile:(NSString *)path { (void)path; return fixtureInfo; }
@end
#define dictionaryWithContentsOfFile wts_dictionaryWithContentsOfFile
static int FakeStat(const char *, struct stat *);
static int FakeGet(int, id_t);
static int FakeSet(int, id_t, int);
static char *FakeRealpath(const char *, char *);
#define lstat(...) FakeStat(__VA_ARGS__)
#define realpath FakeRealpath
#define getpriority FakeGet
#define setpriority FakeSet
#define main WTSUnusedDaemonMain
#include "../Priority/WeTypeCleanSixPriority.m"
#undef main
#undef lstat
#undef realpath
#undef getpriority
#undef setpriority

static NSString *testPath;
static int niceValue, jetValue, niceFailure, jetFailure, readFailure;
static int niceCalls, jetCalls;
static BOOL staleNice, staleJet, wrongJetPID;
static int jetReadFailure, niceSuccessErrno, jetSuccessErrno;
static uid_t fixtureUID = 501;
static mode_t fixtureMode = 0755;
static int badResource = -1, statFailure;
static uid_t badUID;
static mode_t badMode;
static BOOL pathAlias;
static unsigned checkedResources;
static int FakeStat(const char *p, struct stat *st) {
    NSString *file=[NSString stringWithUTF8String:p];
    int index=[file.pathExtension isEqualToString:@"appex"] ? 0 : ([file.lastPathComponent isEqualToString:@"Info.plist"] ? 1 : 2);
    checkedResources |= 1u << index;
    if(index==badResource && statFailure) { errno=ENOENT; return -1; }
    memset(st,0,sizeof(*st)); st->st_uid=index==badResource ? badUID : fixtureUID;
    st->st_mode=index==badResource ? badMode : (fixtureMode | (index==0 ? S_IFDIR : S_IFREG));
    return 0;
}
static char *FakeRealpath(const char *p, char *out) {
    NSString *s=[NSString stringWithUTF8String:p];
    if(pathAlias) s=@"/private/var/mobile/alias/Keyboard";
    else if([s hasPrefix:@"/var/"]) s=[@"/private" stringByAppendingString:s];
    strlcpy(out,s.UTF8String,PATH_MAX); return out;
}
int proc_pidpath(int pid, void *buffer, uint32_t size) {
    assert(pid==123); strlcpy(buffer,testPath.UTF8String,size); return (int)testPath.length;
}
int proc_listpids(uint32_t t, uint32_t f, void *b, int s) { (void)t;(void)f;(void)b;(void)s; return 0; }
static int FakeGet(int which, id_t pid) { assert(which==PRIO_PROCESS && pid==123); errno=readFailure; return readFailure ? -1 : niceValue; }
static int FakeSet(int which, id_t pid, int value) {
    assert(which==PRIO_PROCESS && pid==123 && value==-18); niceCalls++;
    errno=niceFailure; if(niceFailure)return -1; if(!staleNice) niceValue=value; errno=niceSuccessErrno; return 0;
}
int memorystatus_control(uint32_t cmd, int32_t pid, uint32_t flags, void *buffer, size_t size) {
    assert(pid==123);
    if(cmd==1) {
        assert(flags==0 && size==sizeof(WTSPriorityEntry));
        if(jetReadFailure) { errno=jetReadFailure; return -1; }
        WTSPriorityEntry *e=buffer; e->pid=wrongJetPID ? 456:123; e->priority=jetValue; return sizeof(*e);
    }
    assert(cmd==2 && flags==1 && size==sizeof(WTSPriorityProperties));
    WTSPriorityProperties *p=buffer; assert(p->priority==100 && p->user_data==0); jetCalls++;
    errno=jetFailure; if(jetFailure)return -1; if(!staleJet) jetValue=p->priority; errno=jetSuccessErrno; return 0;
}
static void Fixture(NSString *bid) {
    staleNice=NO; staleJet=NO; wrongJetPID=NO; jetReadFailure=0; niceSuccessErrno=0; jetSuccessErrno=0;
    fixtureUID=501; fixtureMode=0755; badResource=-1; statFailure=0; pathAlias=NO; checkedResources=0;
    NSString *bundle=@"/private/var/containers/Bundle/Application/EA850B6A-E2A7-49BF-9356-D8C61C5C0E2D/wxkb.app/PlugIns/wxkb_plugin.appex";
    testPath=[bundle stringByAppendingPathComponent:@"Keyboard"];
    fixtureInfo = @{@"CFBundleIdentifier":bid,@"CFBundleExecutable":@"Keyboard"};
    niceValue=0; jetValue=0; niceFailure=0;jetFailure=0;readFailure=0;niceCalls=0;jetCalls=0;
}
int main(void) { @autoreleasepool {
    Fixture(@"com.tencent.wetype.keyboard"); WTSApply(123,testPath);
    assert(niceCalls==1 && jetCalls==1 && niceValue==-18 && jetValue==100);
    WTSApply(123,testPath); assert(niceCalls==1 && jetCalls==1);
    for(NSString *bid in @[@"com.tencent.wetype",@"com.tencent.xin",@"com.tencent.wetype.keyboard.other"]) {
        Fixture(bid); WTSApply(123,testPath); assert(niceCalls==0 && jetCalls==0);
    }
    Fixture(@"com.tencent.wetype.keyboard"); niceFailure=EPERM; WTSApply(123,testPath);
    assert(niceCalls==1 && jetCalls==1 && niceValue==0);
    Fixture(@"com.tencent.wetype.keyboard"); jetFailure=EINVAL; WTSApply(123,testPath);
    assert(jetCalls==1 && jetValue==0); // no 100/10 fallback
    Fixture(@"com.tencent.wetype.keyboard"); readFailure=ESRCH; WTSApply(123,testPath);
    assert(niceCalls==0 && jetCalls==1);
    Fixture(@"com.tencent.wetype.keyboard"); WTSApply(123,@"/wrong/path"); assert(niceCalls==0 && jetCalls==0);
    Fixture(@"com.tencent.wetype.keyboard"); fixtureUID=0; WTSApply(123,testPath);
    assert(niceCalls==1 && jetCalls==1);
    Fixture(@"com.tencent.wetype.keyboard"); fixtureUID=502; WTSApply(123,testPath);
    assert(niceCalls==0 && jetCalls==0);
    Fixture(@"com.tencent.wetype.keyboard"); fixtureUID=501; fixtureMode=0777; WTSApply(123,testPath);
    assert(niceCalls==0 && jetCalls==0); fixtureMode=0755;
    for(NSNumber *owner in @[@0,@33,@501]) {
        Fixture(@"com.tencent.wetype.keyboard"); fixtureUID=owner.unsignedIntValue;
        WTSApply(123,testPath);
        assert(checkedResources==7 && niceCalls==1 && jetCalls==1 && niceValue==-18 && jetValue==100);
    }
    for(int resource=0; resource<3; resource++) {
        for(int failure=0; failure<7; failure++) {
            Fixture(@"com.tencent.wetype.keyboard"); fixtureUID=33;
            badResource=resource; badUID=33;
            badMode=(resource==0 ? S_IFDIR : S_IFREG)|0755;
            if(failure==0) badUID=502;
            if(failure==1) badMode|=0020;
            if(failure==2) badMode|=0002;
            if(failure==3) badMode=S_IFLNK|0755;
            if(failure==4) badMode=S_IFIFO|0600;
            if(failure==5) badMode=(resource==0 ? S_IFREG : S_IFDIR)|0755;
            if(failure==6) statFailure=1;
            WTSApply(123,testPath); assert(niceCalls==0 && jetCalls==0);
        }
    }
    Fixture(@"com.tencent.wetype.keyboard"); pathAlias=YES;
    WTSApply(123,testPath); assert(niceCalls==0 && jetCalls==0);
    for(NSString *path in @[@"/var/mobile/Keyboard.appex/Keyboard", @"/private/var/containers/Bundle/ApplicationX/Keyboard.appex/Keyboard", @"/private/var/containers/Bundle/Application/UUID/wxkb.app/Keyboard", @"/private/var/containers/Bundle/Application/UUID/wxkb.app/PlugIns/Keyboard.app/Keyboard"]) {
        Fixture(@"com.tencent.wetype.keyboard"); testPath=path;
        WTSApply(123,testPath); assert(niceCalls==0 && jetCalls==0);
    }
    Fixture(@"com.tencent.wetype.keyboard"); fixtureUID=33;
    testPath=[testPath substringFromIndex:8]; // accepted /var alias
    WTSApply(123,testPath); assert(niceCalls==1 && jetCalls==1);
    for(id exe in @[@"Other", @123, @"../Keyboard"]) {
        Fixture(@"com.tencent.wetype.keyboard");
        fixtureInfo=@{@"CFBundleIdentifier":@"com.tencent.wetype.keyboard",@"CFBundleExecutable":exe};
        WTSApply(123,testPath); assert(niceCalls==0 && jetCalls==0);
    }
    // Exercise the real function's verification result, including successful
    // syscalls with wrong readback or errno, not only write-call counts.
    Fixture(@"com.tencent.wetype.keyboard"); assert(WTSApply(123,testPath));
    assert(WTSApply(123,testPath)); assert(niceCalls==1 && jetCalls==1);
    Fixture(@"com.tencent.wetype.keyboard"); niceFailure=EPERM;
    assert(!WTSApply(123,testPath)); assert(jetCalls==1 && jetValue==100);
    Fixture(@"com.tencent.wetype.keyboard"); jetFailure=EINVAL;
    assert(!WTSApply(123,testPath)); assert(niceValue==-18 && jetCalls==1);
    Fixture(@"com.tencent.wetype.keyboard"); readFailure=ESRCH;
    assert(!WTSApply(123,testPath)); assert(niceCalls==0 && jetCalls==1);
    Fixture(@"com.tencent.wetype.keyboard"); staleNice=YES;
    assert(!WTSApply(123,testPath)); assert(jetValue==100);
    Fixture(@"com.tencent.wetype.keyboard"); staleJet=YES;
    assert(!WTSApply(123,testPath)); assert(niceValue==-18);
    Fixture(@"com.tencent.wetype.keyboard"); jetReadFailure=ESRCH;
    assert(!WTSApply(123,testPath)); assert(niceValue==-18 && jetCalls==1);
    Fixture(@"com.tencent.wetype.keyboard"); wrongJetPID=YES;
    assert(!WTSApply(123,testPath)); assert(niceValue==-18);
    Fixture(@"com.tencent.wetype.keyboard"); niceSuccessErrno=EIO;
    assert(!WTSApply(123,testPath)); assert(jetValue==100);
    Fixture(@"com.tencent.wetype.keyboard"); jetSuccessErrno=EIO;
    assert(!WTSApply(123,testPath)); assert(niceValue==-18);
    for(int resource=0;resource<3;resource++) for(uid_t owner=1;owner<=502;owner++) {
        if(owner==33 || owner==501) continue;
        Fixture(@"com.tencent.wetype.keyboard"); badResource=resource; badUID=owner;
        badMode=(resource==0 ? S_IFDIR:S_IFREG)|0755;
        assert(!WTSApply(123,testPath)); assert(!niceCalls && !jetCalls);
    }
    puts("production runtime mocks PASS: resource owners 0/33/501; each directory/Info/executable foreign owner, group/world write, symlink, wrong type, missing resource; parent alias; container/appex/exact ID/executable/PID-path; syscall errors/readback; nice -18/Jetsam100 no fallback");
    return 0;
} }
