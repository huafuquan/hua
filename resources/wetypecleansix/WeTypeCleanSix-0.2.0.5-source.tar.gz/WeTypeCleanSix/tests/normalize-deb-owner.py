#!/usr/bin/env python3
"""Normalize deb tar metadata only; preserve every file payload and mode."""
import io,sys,tarfile,gzip,lzma,bz2,pathlib,hashlib
p=pathlib.Path(sys.argv[1]); raw=p.read_bytes(); assert raw[:8]==b'!<arch>\n'
parts=[]; at=8
while at<len(raw):
    header=raw[at:at+60]; assert header[58:]==b'`\n'
    size=int(header[48:58]); name=header[:16].decode().strip().rstrip('/')
    blob=raw[at+60:at+60+size]; at+=60+size+(size%2)
    if name.startswith(('control.tar','data.tar')):
        with tarfile.open(fileobj=io.BytesIO(blob),mode='r:*') as src:
            output=io.BytesIO()
            with tarfile.open(fileobj=output,mode='w',format=tarfile.GNU_FORMAT) as dst:
                for item in src:
                    payload=src.extractfile(item) if item.isfile() else None
                    item.uid=item.gid=0; item.uname='root'; item.gname='wheel'
                    dst.addfile(item,payload)
        tar=output.getvalue()
        if name.endswith('.gz'): blob=gzip.compress(tar,mtime=0)
        elif name.endswith(('.xz','.lzma')): blob=lzma.compress(tar,format=lzma.FORMAT_XZ if name.endswith('.xz') else lzma.FORMAT_ALONE)
        elif name.endswith('.bz2'): blob=bz2.compress(tar)
        else: blob=tar
    parts.append((name,blob))
result=bytearray(b'!<arch>\n')
for name,blob in parts:
    header=f'{name+"/":<16}{0:<12}{0:<6}{0:<6}{"100644":<8}{len(blob):<10}`\n'.encode()
    assert len(header)==60
    result+=header+blob+(b'\n' if len(blob)%2 else b'')
p.write_bytes(result)
print('normalized numeric owner 0:0 on Mac:',p,hashlib.sha256(result).hexdigest())
