#include <assert.h>
#include <errno.h>
#include "../Priority/WeTypeCleanSixPriorityPolicy.h"
int main(void) {
    assert(WTSIsTarget("com.tencent.wetype.keyboard"));
    assert(!WTSIsTarget(NULL));
    assert(!WTSIsTarget("com.tencent.wetype"));
    assert(!WTSIsTarget("com.tencent.xin"));
    assert(!WTSIsTarget("com.tencent.wetype.keyboard.other"));
    assert(!WTSIsTarget("COM.tencent.wetype.keyboard"));
    assert(WTS_NICE == -18 && WTS_JETSAM == 100);
    assert(WTSVerified(0,0,-18,0,WTS_NICE));
    assert(WTSVerified(0,0,100,0,WTS_JETSAM));
    assert(!WTSVerified(-1,EPERM,-18,0,WTS_NICE));
    assert(!WTSVerified(-1,EACCES,100,0,WTS_JETSAM));
    assert(!WTSVerified(0,0,-1,ESRCH,WTS_NICE));
    assert(!WTSVerified(0,0,-1,0,WTS_NICE));
    assert(!WTSVerified(0,0,10,0,WTS_JETSAM));
    assert(!WTSVerified(0,0,100,EIO,WTS_JETSAM));
    assert(WTS_PERIOD_SECONDS==1800 && WTS_LEEWAY_SECONDS==60);
    WTSWakeGate sender={0}, receiver={0};
    assert(WTSAdmitWake(&sender,0)); // zero uptime is not an unset sentinel
    assert(WTSAdmitWake(&receiver,0));
    assert(!WTSAdmitWake(&sender,1));
    assert(!WTSAdmitWake(&receiver,4999999999ull));
    assert(WTSAdmitWake(&sender,5000000000ull));
    assert(WTSAdmitWake(&receiver,5000000000ull));
    assert(!WTSAdmitWake(&sender,9999999999ull));
    assert(WTSAdmitWake(&sender,10000000000ull)); // exact boundary
    bool visible=false;
    assert(WTSVisibilityAppeared(&visible));
    assert(!WTSVisibilityAppeared(&visible)); // repeat didAppear != open
    visible=false; // didDisappear after original implementation
    assert(WTSVisibilityAppeared(&visible));
    assert(!WTSVisibilityAppeared(&visible));
    return 0;
}
