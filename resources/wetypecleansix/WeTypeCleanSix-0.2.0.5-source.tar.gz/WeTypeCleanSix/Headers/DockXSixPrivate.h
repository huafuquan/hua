#pragma once
#import <UIKit/UIKit.h>
// Confirmed in upstream DockX.h and DockX 2.5.4 Objective-C metadata/disassembly.
@interface UIKeyboardImpl : UIView
+ (instancetype)activeInstance;
@property(nonatomic, readonly) id inputDelegate;
@property(nonatomic, readonly) id inputDelegateManager;
- (void)updateReturnKey;
- (void)clearTransientState;
- (void)clearAnimations;
- (void)setCaretBlinks:(BOOL)blinks;
- (void)deleteFromInput;
- (void)insertText:(NSString *)text;
- (void)dismissKeyboard;
- (BOOL)isUsingDictationLayout;
@end
@interface UIKeyboardDockItem : NSObject
@property(nonatomic, readonly) UIView *view;
@property(nonatomic, readonly) UIButton *button;
@end
@interface UIKeyboardDockView : UIView
@property(nonatomic, readonly) UIKeyboardDockItem *centerDockItem;
@end
@interface UISystemKeyboardDockController : NSObject
@property(nonatomic, readonly) UIKeyboardDockView *dockView;
@end
@interface NSObject (DockXSixInputDeclarations)
- (void)selectAll;
- (void)insertText:(NSString *)text;
- (void)clearForwardingInputDelegateAndResign:(BOOL)resign;
@end
