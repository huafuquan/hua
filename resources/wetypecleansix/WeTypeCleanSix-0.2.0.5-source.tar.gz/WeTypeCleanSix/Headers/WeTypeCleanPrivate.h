#pragma once

#import <UIKit/UIKit.h>

// Recovered from KeyboardX 1.1-6 arm64 hook registrations and selector refs.
@interface WBKeyViewItem : NSObject
- (double)cornerRadius;
- (void)parseBaseProperties;
@end

@interface WBKeyView : UIView
- (CALayer *)backgroundLayer;
- (void)updateBackgroundColor;
@end

@interface WBCandidateCell : UIView
- (void)renderCandidateWord:(id)word focusedStyle:(BOOL)focused atIndex:(NSInteger)index;
@end
