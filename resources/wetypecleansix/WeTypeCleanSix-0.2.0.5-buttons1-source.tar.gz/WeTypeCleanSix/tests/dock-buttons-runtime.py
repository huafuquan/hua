#!/usr/bin/env python3
"""Generate a small Objective-C runtime harness using the actual helper bodies.
Linux: python3 tests/dock-buttons-runtime.py /tmp/dock-test.m
clang -Wall -Wextra -Werror /tmp/dock-test.m /usr/lib/libobjc.so.4 -o /tmp/dock-test && /tmp/dock-test
This exercises view targeting, not UIKit layout or rendering.
"""
from pathlib import Path
import sys
source = (Path(__file__).resolve().parents[1] / 'Hooks/WeTypeCleanDockButtons.xm').read_text()
helpers = source[source.index('static void WeTypeCleanSixHideSideItem'):source.index('%group')]
harness = r'''
#include <assert.h>
#include <stdio.h>
typedef signed char BOOL;
#define YES ((BOOL)1)
#define NO ((BOOL)0)
#define nil ((id)0)
extern id class_createInstance(Class, unsigned long);
static Class object_getClass(id obj) { return obj ? *(Class *)(void *)obj : (Class)0; }
extern Class class_getSuperclass(Class);
extern void *class_getInstanceMethod(Class, SEL);
__attribute__((objc_root_class))
@interface NSObject { Class isa; }
+ (id)new;
+ (Class)class;
- (BOOL)respondsToSelector:(SEL)sel;
- (BOOL)isKindOfClass:(Class)cls;
@end
@implementation NSObject
+ (id)new { return class_createInstance(self, 0); }
+ (Class)class { return self; }
- (BOOL)respondsToSelector:(SEL)sel { return class_getInstanceMethod(object_getClass(self), sel) != 0; }
- (BOOL)isKindOfClass:(Class)cls {
    for (Class c = object_getClass(self); c; c = class_getSuperclass(c)) if (c == cls) return YES;
    return NO;
}
@end
@interface UIView : NSObject { BOOL _hidden; UIView *_parent; }
@property BOOL hidden;
@property(assign) UIView *parent;
- (BOOL)isDescendantOfView:(UIView *)view;
@end
@implementation UIView
@synthesize hidden = _hidden, parent = _parent;
- (BOOL)isDescendantOfView:(UIView *)view {
    for (UIView *v = self; v; v = v.parent) if (v == view) return YES;
    return NO;
}
@end
@interface UIButton : UIView @end
@implementation UIButton @end
@interface UIKeyboardDockItem : NSObject { UIView *_view; UIButton *_button; }
@property(assign) UIView *view;
@property(assign) UIButton *button;
@end
@implementation UIKeyboardDockItem
@synthesize view = _view, button = _button;
@end
@interface UIKeyboardDockView : UIView {
 UIKeyboardDockItem *_leftDockItem, *_rightDockItem, *_centerDockItem;
}
@property(assign) UIKeyboardDockItem *leftDockItem;
@property(assign) UIKeyboardDockItem *rightDockItem;
@property(assign) UIKeyboardDockItem *centerDockItem;
@end
@implementation UIKeyboardDockView
@synthesize leftDockItem = _leftDockItem, rightDockItem = _rightDockItem, centerDockItem = _centerDockItem;
@end
'''
cases = r'''
int main(void) {
 UIKeyboardDockView *dock = [UIKeyboardDockView new];
 WeTypeCleanSixHideDockButtons(dock); // missing items
 UIKeyboardDockItem *left = [UIKeyboardDockItem new], *right = [UIKeyboardDockItem new];
 UIKeyboardDockItem *center = [UIKeyboardDockItem new];
 UIButton *l = [UIButton new], *r = [UIButton new], *c = [UIButton new];
 UIView *six = [UIView new];
 l.parent = r.parent = c.parent = six.parent = dock;
 left.view = l; left.button = l; right.view = r; right.button = r;
 center.view = c; center.button = c;
 dock.leftDockItem = left; dock.rightDockItem = right; dock.centerDockItem = center;
 WeTypeCleanSixHideDockButtons(dock);
 assert(l.hidden && r.hidden && !c.hidden && !six.hidden && !dock.hidden);
 l.hidden = r.hidden = NO;
 WeTypeCleanSixHideDockButtons(dock); // system restores visibility
 assert(l.hidden && r.hidden);
 UIButton *replacement = [UIButton new]; replacement.parent = dock;
 right.view = replacement; right.button = replacement;
 WeTypeCleanSixHideDockButtons(dock); assert(replacement.hidden);
 UIView *foreign = [UIView new]; left.view = foreign; left.button = (id)foreign;
 WeTypeCleanSixHideDockButtons(dock); assert(!foreign.hidden);
 left.view = dock; left.button = (id)dock;
 WeTypeCleanSixHideDockButtons(dock); assert(!dock.hidden);
 dock.leftDockItem = center;
 WeTypeCleanSixHideDockButtons(dock); assert(!c.hidden);
 dock.leftDockItem = (id)[NSObject new]; // unsupported item selectors
 WeTypeCleanSixHideDockButtons(dock);
 puts("dock side-item behavior assertions PASS");
 return 0;
}
'''
Path(sys.argv[1]).write_text(harness + helpers + cases)
