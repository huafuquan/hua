# 0.2.0.5+buttons1

Base: exact uploaded WeTypeCleanSix-0.2.0.5-source.tar.gz; original manifest verified.
This is an independent 0205 branch, not a continuation of 0208.

Adds Hooks/WeTypeCleanDockButtons.xm, automatically collected by the unchanged Makefile.
UIKeyboardDockView.layoutSubviews calls the original, then hides views/buttons of leftDockItem and rightDockItem. Accessors are checked before calling them. Views must be descendants of the dock and cannot be the dock itself; an item identical to centerDockItem is skipped. No frames, constraints, dock items, center visibility or priority settings are changed. Both side buttons are always hidden; no preferences are added because supplied screenshots show keyboard views, not preference controls.

Runtime-header evidence:
https://github.com/nst/iOS-Runtime-Headers/blob/master/PrivateFrameworks/UIKitCore.framework/UIKeyboardDockView.h
https://github.com/nst/iOS-Runtime-Headers/blob/master/PrivateFrameworks/UIKitCore.framework/UIKeyboardDockItem.h
These establish accessor existence in documented runtime dumps; current device rendering still requires validation.

Screenshot analysis used apple-vision OCR on photo_B1BC02ED.png (1290x1082 keyboard crop) and photo_367D3D96.jpg (1181x2560 Settings search with keyboard and six-button row). No preference controls were identified. Implementation targets the system dock sides rather than WeType's in-keyboard language/voice keys.

All baseline files except control and MANIFEST.sha256 are byte-identical, including Priority/*, Hooks/WeTypeCleanPriorityWake.xm, layout/*, filter, Makefile, existing tests, all existing Hooks/Headers/Sources. Version is 0.2.0.5+buttons1.

Validation completed:
- Baseline manifest: 30 entries PASS.
- Original tests/priority-policy.c: compiled with -Wall -Wextra -Werror and executed PASS.
- New Logos preprocessing and iOS 16.5 arm64e SDK syntax check: -Wall -Wextra -Werror PASS.
- tests/dock-buttons-runtime.py: executes actual helper bodies in a GNU Objective-C mock runtime; missing items/accessors, both sides, repeated layouts, replacement item, unrelated view, dock itself and center alias PASS. Does not emulate UIKit rendering.
- Original Foundation runtime and wake runtime tests require macOS and were not executed; their source remains unchanged.

Build blockers:
- Both known Mac addresses (192.168.0.147 and 192.168.0.103) timed out on SSH using the existing key/account.
- Local Theos compiler aborted with std::system_error / No error information while compiling the unchanged Hooks/DockXSixMain.xm. No deb was produced.
- No cloud build, install, publication, device process restart or settings write was performed.

Mac build when reachable: from the source directory, export THEOS=$HOME/theos and PATH=/opt/homebrew/bin:/usr/local/bin:$THEOS/bin:$PATH, run sh tests/run-mac-tests.sh, then gmake clean THEOS_PACKAGE_SCHEME=roothide and gmake -j1 package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=roothide ARCHS=arm64e. Run tests/normalize-deb-owner.py on the generated deb before delivery. Do not install automatically.

Device acceptance still needed: verify left globe and right dictation controls stay hidden across keyboard reopen, switching keyboards, number-pad mode, orientation changes and light/dark appearance; verify center dictation UI, six-button actions, long-press/interaction and original priority behavior.
