#import "DockXSixPrivate.h"
#import <objc/runtime.h>

// UIKitCore UIKeyboardDockView runtime headers expose these two dock items.
// Keep these declarations local: the original DockXSix implementation is unchanged.
@interface UIKeyboardDockView (WeTypeCleanSixSideItems)
- (UIKeyboardDockItem *)leftDockItem;
- (UIKeyboardDockItem *)rightDockItem;
@end

static void WeTypeCleanSixHideSideItem(UIKeyboardDockItem *item, UIKeyboardDockView *dock) {
    if (!item) return;
    UIView *view = [item respondsToSelector:@selector(view)] ? item.view : nil;
    UIButton *button = [item respondsToSelector:@selector(button)] ? item.button : nil;
    // Restrict changes to actual descendants of this dock, never the dock itself.
    if ([view isKindOfClass:UIView.class] && view != dock && [view isDescendantOfView:dock]) {
        view.hidden = YES;
    }
    if ([button isKindOfClass:UIView.class] && button != (id)dock && [button isDescendantOfView:dock]) {
        button.hidden = YES;
    }
}

static void WeTypeCleanSixHideDockButtons(UIKeyboardDockView *dock) {
    UIKeyboardDockItem *center = [dock respondsToSelector:@selector(centerDockItem)] ? dock.centerDockItem : nil;
    UIKeyboardDockItem *left = [dock respondsToSelector:@selector(leftDockItem)] ? [dock leftDockItem] : nil;
    UIKeyboardDockItem *right = [dock respondsToSelector:@selector(rightDockItem)] ? [dock rightDockItem] : nil;
    // A central dictation/other system item continues to control DockXSix visibility.
    if (left != center) WeTypeCleanSixHideSideItem(left, dock);
    if (right != center) WeTypeCleanSixHideSideItem(right, dock);
}

%group WeTypeCleanSixDockButtons
%hook UIKeyboardDockView
- (void)layoutSubviews {
    %orig;
    // UIKit may restore button visibility during layout or replace either item.
    // Apply after its layout without changing constraints, frames or item identity.
    WeTypeCleanSixHideDockButtons(self);
}
%end
%end

%ctor {
    @autoreleasepool {
        Class dock = objc_getClass("UIKeyboardDockView");
        if (dock && class_getInstanceMethod(dock, @selector(layoutSubviews))) {
            %init(WeTypeCleanSixDockButtons);
        }
    }
}
